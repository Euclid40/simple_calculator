package com.example;

public class AppTest {
    public static void main(String[] args) {
        System.out.println("Running AppTest...");
    }
}
