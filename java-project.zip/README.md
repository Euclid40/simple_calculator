# Java Project

## Description
A basic Java project structure for getting started with Java development.

## Requirements
- JDK 8 or higher
- Optional: Gradle or Maven for build management

## Setup and Run

### Compile
```bash
javac -d out src/main/java/com/example/App.java
```

### Run
```bash
java -cp out com.example.App
```

### Run Tests
```bash
javac -d out src/test/java/com/example/AppTest.java
java -cp out com.example.AppTest
```

## Structure
- `src/main/java`: Main Java source code
- `src/test/java`: Test Java files
- `out/`: Compiled class files

## License
MIT
